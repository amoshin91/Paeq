require 'test_helper'

class AddCommentToUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
