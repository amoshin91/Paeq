class AddCommentToUser < ApplicationRecord
  belongs_to :comment
end
